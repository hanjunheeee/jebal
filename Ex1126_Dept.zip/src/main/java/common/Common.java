package common;

public class Common {
	public static class Dept{
		public static final String VIEW_PATH = "/WEB-INF/views/dept/";
	}
}
